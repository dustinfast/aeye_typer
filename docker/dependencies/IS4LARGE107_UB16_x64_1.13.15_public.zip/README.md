# Tobii 4L Platform Development Kit (PDK)

This README describes how to get started with the Tobii 4L PDK for Linux.

## Contents

The PDK package contains the following:

* Tobii Stream Engine: library providing an API for interacting with the Tobii Eye Tracker
* Tobii Stream Engine API documentation
* Platform Runtime: driver for the Tobii 4L Eye Tracker
* License Agreement
* Required third-party libraries and licenses
* This README


## Getting Started

### Prerequisites

This software package is supported on Ubuntu 16.04.

Plug in your Tobii 4L Eye Tracker.


### Installing and starting the Platform Runtime

The Platform Runtime installer is available in the platform_runtime folder.

To install and start the runtime, run the installer **as root/with sudo**, with argument '--install': 

```
sudo platform_runtime_IS4LARGE107_install.sh --install
```

To uninstall the runtime, run the installer with argument '--uninstall':

```
sudo platform_runtime_IS4LARGE107_install.sh --uninstall
```

### Using the Stream Engine library

For an introduction to the Stream Engine, see [Stream Engine on DevZone](https://developer.tobii.com/consumer-eye-trackers/stream-engine/).

A full API reference is provided in the PDK package. 

Have a question? Please visit the forums on [Tobii Developer Zone](https://developer.tobii.com).







